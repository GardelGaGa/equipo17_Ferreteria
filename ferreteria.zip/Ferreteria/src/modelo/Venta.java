/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.Date;



public class Venta {
    private int idVenta;
    private Date fechaVenta;
    private int fkIdUsuario;
    private double totalVenta;
    private String metodoPago;

    public Venta(int idVenta, Date fechaVenta, int fkIdUsuario, double totalVenta, String metodoPago) {
        this.idVenta = idVenta;
        this.fechaVenta = fechaVenta;
        this.fkIdUsuario = fkIdUsuario;
        this.totalVenta = totalVenta;
        this.metodoPago = metodoPago;
    }
    public Venta(Date fechaVenta, int fkIdUsuario, double totalVenta, String metodoPago) {
        this.fechaVenta = fechaVenta;
         this.fkIdUsuario = fkIdUsuario;
        this.totalVenta = totalVenta;
        this.metodoPago = metodoPago;
    }
    

    public int getIdVenta() {
        return idVenta;
    }

    public Date getFechaVenta() {
        return fechaVenta;
    }

    public int getFkIdUsuario() {
        return fkIdUsuario;
    }

    public double getTotalVenta() {
        return totalVenta;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public void setFechaVenta(Date fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public void setFkIdUsuario(int fkIdUsuario) {
        this.fkIdUsuario = fkIdUsuario;
    }

    public void setTotalVenta(double totalVenta) {
        this.totalVenta = totalVenta;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    @Override
    public String toString() {
        return "Venta{" + "idVenta=" + idVenta + ", fechaVenta=" + fechaVenta + ", fkIdUsuario=" + fkIdUsuario + ", totalVenta=" + totalVenta + ", metodoPago=" + metodoPago + '}';
    }

}
