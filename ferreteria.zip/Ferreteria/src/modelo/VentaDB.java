package modelo;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class VentaDB {

    public void guardarVentaEnBaseDeDatos(int idUsuario, String metodoPago, double totalVenta, List<DetalleVenta> detallesVenta) {
    try {
        // Crear una conexión a la base de datos
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ferreteria", "Prueba", "Valentino123");

        // Crear una declaración SQL
        Statement stmt = conn.createStatement();

        // Formatear la fecha actual al formato de MySQL
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaVenta = sdf.format(new Date());

        // Crear la consulta SQL para insertar la venta
        String sqlVenta = "INSERT INTO ventas (idventa, fechaventa, fk_idusuario, totalventa, metodopago) VALUES (NULL, '" + fechaVenta + "', " + idUsuario + ", " + totalVenta + ", '" + metodoPago + "')";

        // Ejecutar la consulta SQL para insertar la venta
        stmt.executeUpdate(sqlVenta, Statement.RETURN_GENERATED_KEYS);

        // Obtener el ID de la venta que acabamos de insertar
        ResultSet rs = stmt.getGeneratedKeys();
        rs.next();
        int idVenta = rs.getInt(1);

        // Insertar cada detalle de la venta en la tabla detalleventa
        for (DetalleVenta detalle : detallesVenta) {
            String sqlDetalle = "INSERT INTO detalleventa (fk_idventa, fk_idproducto_, cantidad, preciounitario, subtotal) VALUES (" + idVenta + ", " + detalle.getCodigoProducto() + ", " + detalle.getCantidad() + ", " + detalle.getPrecioUnitario() + ", " + detalle.getSubtotal() + ")";
            stmt.executeUpdate(sqlDetalle);
        }

        // Cerrar la conexión
        conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}