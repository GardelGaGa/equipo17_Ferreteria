/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class UsuariosDAO {

    private Connection conexion;

    public UsuariosDAO(Connection conexion) {
         this.conexion = conexion;
        // Inicializar la conexión a la base de datos
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/ferreteria", "Prueba", "Valentino123");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public boolean verificarUsuario(String username, String password) throws SQLException {
        boolean isValid = false;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            // Consulta para verificar si el usuario y contraseña son válidos
            String query = "SELECT COUNT(*) FROM usuarios WHERE nombreusuario = ? AND contraseña = ?";
            statement = conexion.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            resultSet = statement.executeQuery();
            
            // Si el resultado tiene al menos una fila, el usuario y contraseña son válidos
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                isValid = count > 0;
            }
        } finally {
            // Cerrar recursos
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
        }

        return isValid;
    }


    public void insertarUsuario(Usuario usuario) throws SQLException {
        try {
            PreparedStatement statement = conexion.prepareStatement("INSERT INTO usuarios (nombre, apellido, cargo, nombreusuario, contraseña, correoelectronico, fechacontratacion, salario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            statement.setString(1, usuario.getNombre());
            statement.setString(2, usuario.getApellido());
            statement.setString(3, usuario.getCargo());
            statement.setString(4, usuario.getNombreUsuario());
            statement.setString(5, usuario.getContraseña());
            statement.setString(6, usuario.getCorreoElectronico());
            // Convertir la fecha de tipo Date a String
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String fechaContratacionString = dateFormat.format(usuario.getFechaContratacion());
            statement.setString(7, fechaContratacionString);
            statement.setDouble(8, usuario.getSalario());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet obtenerUsuarios() throws SQLException {
        try {
            PreparedStatement statement = conexion.prepareStatement("SELECT * FROM usuarios");
            return statement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void actualizarUsuario(Usuario usuario) throws SQLException {
        try {
            PreparedStatement statement = conexion.prepareStatement("UPDATE usuarios SET nombre = ?, apellido = ?, cargo = ?, nombreusuario = ?, contraseña = ?, correo_electronico = ?, fechacontratacion = ?, salario = ? WHERE idusuario = ?");
            statement.setString(1, usuario.getNombre());
            statement.setString(2, usuario.getApellido());
            statement.setString(3, usuario.getCargo());
            statement.setString(4, usuario.getNombreUsuario());
            statement.setString(5, usuario.getContraseña());
            statement.setString(6, usuario.getCorreoElectronico());
            // Convertir la fecha de tipo Date a String
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String fechaContratacionString = dateFormat.format(usuario.getFechaContratacion());
            statement.setString(7, fechaContratacionString);
            statement.setDouble(8, usuario.getSalario());
            statement.setInt(9, usuario.getIdUsuario());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarUsuario(int idUsuario) throws SQLException {
        try {
            PreparedStatement statement = conexion.prepareStatement("DELETE FROM usuarios WHERE idusuario = ?");
            statement.setInt(1, idUsuario);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
     public String obtenerRolUsuario(String username) throws SQLException {
        String role = null;
        String query = "SELECT cargo FROM usuarios WHERE nombreusuario = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    role = resultSet.getString("cargo");
                }
            }
        }
        return role;
    }
     public int obtenerIdUsuarioActual(String nombreUsuario) throws SQLException {
        int idUsuario = -1;
        String consulta = "SELECT idusuario FROM usuarios WHERE nombreusuario = ?";
        try (PreparedStatement statement = conexion.prepareStatement(consulta)) {
            statement.setString(1, nombreUsuario);
            try (ResultSet resultado = statement.executeQuery()) {
                if (resultado.next()) {
                    idUsuario = resultado.getInt("idusuario");
                }
            }
        }
        return idUsuario;
    }

    public String obtenerNombreUsuarioActual(int idUsuario) throws SQLException {
        String nombreUsuario = null;
        String query = "SELECT nombreusuario FROM usuarios WHERE idusuario = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setInt(1, idUsuario);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    nombreUsuario = resultSet.getString("nombreusuario");
                }
            }
        }
        return nombreUsuario;
    }


}
