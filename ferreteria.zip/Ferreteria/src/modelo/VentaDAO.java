/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author alary
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class VentaDAO {
    private Connection conexion;

    public VentaDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean agregarVenta(Venta venta, List<DetalleVenta> detallesVenta) throws SQLException {
        String sqlVenta = "INSERT INTO Ventas (fechaventa, fk_idusuario, totalventa, metodopago) VALUES (?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO DetalleVenta (fk_idventa, fk_idproducto_, cantidad, preciounitario, subtotal) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement statementVenta = conexion.prepareStatement(sqlVenta, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statementVenta.setDate(1, new java.sql.Date(venta.getFechaVenta().getTime()));
            statementVenta.setInt(2, venta.getFkIdUsuario());
            statementVenta.setDouble(3, venta.getTotalVenta());
            statementVenta.setString(4, venta.getMetodoPago());
            int affectedRows = statementVenta.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Error al insertar la venta, no se afectaron filas.");
            }

            try (ResultSet generatedKeys = statementVenta.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int idVenta = generatedKeys.getInt(1);
                    for (DetalleVenta detalle : detallesVenta) {
                        try (PreparedStatement statementDetalle = conexion.prepareStatement(sqlDetalle)) {
                            statementDetalle.setInt(1, idVenta);
                            statementDetalle.setString(2, detalle.getCodigoProducto());
                            statementDetalle.setInt(3, detalle.getCantidad());
                            statementDetalle.setDouble(3, detalle.getPrecioUnitario());
                            statementDetalle.setDouble(5, detalle.getSubtotal());
                            statementDetalle.executeUpdate();
                        }
                    }
                } else {
                    throw new SQLException("Error al insertar la venta, no se pudo obtener el ID.");
                }
            }
        }
        return true;
    }

    public List<Venta> obtenerTodasVentas() throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        String sql = "SELECT * FROM Ventas";
        try (PreparedStatement statement = conexion.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int idVenta = resultSet.getInt("idventa");
                Date fechaVenta = resultSet.getDate("fecha_venta");
                int fkIdUsuario = resultSet.getInt("fk_idusuario");
                double totalVenta = resultSet.getDouble("totalventa");
                String metodoPago = resultSet.getString("metodo_pago");
                Venta venta = new Venta(idVenta, fechaVenta, fkIdUsuario, totalVenta, metodoPago);
                ventas.add(venta);
            }
        }
        return ventas;
    }

    public void actualizarVenta(Venta venta) throws SQLException {
        String sql = "UPDATE Ventas SET fecha_venta=?, fk_idusuario=?, totalventa=?, metodo_pago=? WHERE idventa=?";
        try (PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setDate(1, new java.sql.Date(venta.getFechaVenta().getTime()));
            statement.setInt(2, venta.getFkIdUsuario());
            statement.setDouble(3, venta.getTotalVenta());
            statement.setString(4, venta.getMetodoPago());
            statement.setInt(5, venta.getIdVenta());
            statement.executeUpdate();
        }
    }

    public void eliminarVenta(int idVenta) throws SQLException {
        String sql = "DELETE FROM Ventas WHERE idventa=?";
        try (PreparedStatement statement = conexion.prepareStatement(sql)) {
            statement.setInt(1, idVenta);
            statement.executeUpdate();
        }
    }
}