/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.Connection;
import modelo.UsuariosDAO;
import java.sql.SQLException;
import modelo.UsuariosDAO;
import vista.PuntodeVentaPanel;
/**
 *
 * @author alary
 */
public class LoginController {
    private UsuariosDAO usuariosDAO;
    private Connection conexion;

    public LoginController(Connection conexion) {
        this.conexion = conexion;
        this.usuariosDAO = new UsuariosDAO(conexion);
    }

    public boolean iniciarSesion(String nombreUsuario, String contraseña) {
        try {
            boolean esValido = usuariosDAO.verificarUsuario(nombreUsuario, contraseña);
            if (esValido) {
                // Crear una instancia de PuntoDeVentaPanel con el nombre de usuario actual
                PuntodeVentaPanel puntoeVentaPanel = new PuntodeVentaPanel(conexion, nombreUsuario);
                // Aquí puedes continuar con el flujo de la aplicación, como mostrar el panel de punto de venta
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar el usuario: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }
    
}
