/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import javax.swing.JFrame;
import java.sql.Connection;
import controlador.Conexion;
import vista.PuntodeVentaPanel;

public class Main {

    public static void main(String[] args) {
        Conexion conexionDB = new Conexion();
        Connection conexion = conexionDB.conectar();

        if (conexion == null) {
            System.err.println("Error: No se pudo establecer la conexión a la base de datos.");
            return; // Detener la ejecución si no hay conexión
        }
        String nombreUsuarioActual = "tuNombreDeUsuario";

        javax.swing.SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Punto de Venta");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new PuntodeVentaPanel(conexion, nombreUsuarioActual));
            frame.pack();
            frame.setVisible(true);
        });
    }
}

