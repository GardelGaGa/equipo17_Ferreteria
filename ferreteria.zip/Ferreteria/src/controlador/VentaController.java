/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

/**
 *
 * @author alary
 */

import modelo.Venta;
import modelo.VentaDAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import modelo.DetalleVenta;

public class VentaController {

    private VentaDAO ventaDAO;
    private DetalleVenta detalleVenta;

    public VentaController(VentaDAO ventaDAO) {
        this.ventaDAO = ventaDAO;
    }

    public void agregarVenta(Venta venta, List<DetalleVenta> detallesVenta) {
        try {
            ventaDAO.agregarVenta(venta, detallesVenta);
            System.out.println("Venta agregada correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al agregar venta: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public List<Venta> obtenerTodasVentas() {
        try {
            return ventaDAO.obtenerTodasVentas();
        } catch (SQLException ex) {
            System.out.println("Error al obtener ventas: " + ex.getMessage());
            ex.printStackTrace();
            return null;
        }
    }

    public void actualizarVenta(Venta venta) {
        try {
            ventaDAO.actualizarVenta(venta);
            System.out.println("Venta actualizada correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al actualizar venta: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void eliminarVenta(int idVenta) {
        try {
            ventaDAO.eliminarVenta(idVenta);
            System.out.println("Venta eliminada correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al eliminar venta: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
